package com.ssafy.movie.service;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.movie.dao.MovieDao;
import com.ssafy.movie.dao.MovieDaoImpl;
import com.ssafy.movie.dto.Movie;

public class MovieServiceImpl implements MovieService {
	private static MovieServiceImpl instance = MovieServiceImpl.getInstance();
	private MovieDao movieDao = MovieDaoImpl.getInstance();

	private MovieServiceImpl() {
	}

	public static MovieServiceImpl getInstance() {
		return instance;
	}

	@Override
	public int insert(Movie movie) throws SQLException {
		return movieDao.insert(movie);
	}

	@Override
	public List<Movie> selectAll() throws SQLException {
		return movieDao.selectAll();
	}

	@Override
	public Movie select(String code) throws SQLException {
		return movieDao.select(code);
	}

	@Override
	public List<Movie> selectTitle(String title) throws SQLException {
		return movieDao.selectTitle(title);
	}

	@Override
	public List<Movie> selectPrice(int price) throws SQLException {
		return movieDao.selectPrice(price);
	}

	@Override
	public int delete(String code) throws SQLException {
		return movieDao.delete(code);
	}

	@Override
	public int update(Movie movie) throws SQLException {
		return movieDao.update(movie);
	}

}
