package com.ssafy.movie.service;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.movie.dto.Movie;

public interface MovieService {
	// 영화정보 추가
	int insert(Movie movie) throws SQLException;

	// 전체 조회
	List<Movie> selectAll() throws SQLException;

	// 조회 by 코드
	Movie select(String code) throws SQLException;

	// 조회 by 제목
	List<Movie> selectTitle(String title) throws SQLException;

	// 조회 by 가격
	List<Movie> selectPrice(int price) throws SQLException;

	// 영화정보 삭제
	int delete(String code) throws SQLException;

	// 영화정보 업데이트
	int update(Movie movie) throws SQLException;
}
