package com.ssafy.movie.service;

import java.sql.SQLException;

import com.ssafy.movie.dto.User;

public interface UserService {
	User select(String id) throws SQLException;
}
