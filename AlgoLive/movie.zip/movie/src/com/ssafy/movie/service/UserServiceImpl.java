package com.ssafy.movie.service;

import java.sql.SQLException;

import com.ssafy.movie.dao.UserDao;
import com.ssafy.movie.dao.UserDaoImpl;
import com.ssafy.movie.dto.User;

public class UserServiceImpl implements UserService {
	private static UserServiceImpl instance = new UserServiceImpl();
	private UserServiceImpl() {
	}
	
	
	public static UserServiceImpl getInstance() {
		return instance;
	}
	
	private UserDao userDao = UserDaoImpl.getInstance();

	@Override
	public User select(String id) throws SQLException {
		return userDao.select(id);
	}

}
