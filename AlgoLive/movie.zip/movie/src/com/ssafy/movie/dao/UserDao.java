package com.ssafy.movie.dao;

import java.sql.SQLException;

import com.ssafy.movie.dto.User;

public interface UserDao {
	User select(String id) throws SQLException;
}
