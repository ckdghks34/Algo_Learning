package com.ssafy.movie.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.ssafy.movie.dto.User;
import com.ssafy.movie.util.DBUtil;

public class UserDaoImpl implements UserDao {

	private static UserDaoImpl instance = new UserDaoImpl();
	private DBUtil dbutil = DBUtil.getInstance();

	private UserDaoImpl() {
	}

	public static UserDaoImpl getInstance() {
		return instance;
	}

	@Override
	public User select(String id) throws SQLException {
		String sql = "select * from user where id = ?";

		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		User user = null;

		try {
			conn = dbutil.getConnection();
			ps = conn.prepareStatement(sql);
			ps.setString(1, id);

			rs = ps.executeQuery();
			if (rs.next())
				user = new User(id, rs.getString("pass"), rs.getString("name"));

		} finally {
			dbutil.close(rs, ps, conn);
		}

		return user;
	}
	public static void main(String[] args) throws Exception{
		UserDao dao = UserDaoImpl.getInstance();
		
		System.out.println(dao.select("ssafy"));
	}
}
