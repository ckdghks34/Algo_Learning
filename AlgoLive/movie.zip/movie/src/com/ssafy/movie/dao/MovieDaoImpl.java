package com.ssafy.movie.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ssafy.movie.dto.Movie;
import com.ssafy.movie.util.DBUtil;

public class MovieDaoImpl implements MovieDao {
	private static MovieDaoImpl instance = new MovieDaoImpl();
	private DBUtil dbutil = DBUtil.getInstance();

	private MovieDaoImpl() {
	}

	public static MovieDaoImpl getInstance() {
		return instance;
	}

	@Override
	public int insert(Movie movie) throws SQLException {
		String sql = "insert into movie values (?,?,?,?)";

		Connection conn = null;
		PreparedStatement ps = null;

		int result = -1;
		try {
			conn = dbutil.getConnection();
			ps = conn.prepareStatement(sql);
			ps.setString(1, movie.getCode());
			ps.setString(2, movie.getTitle());
			ps.setInt(3, movie.getPrice());
			ps.setString(4, movie.getNo());

			result = ps.executeUpdate();
		} finally {
			dbutil.close(ps, conn);
		}

		return result;
	}

	@Override
	public List<Movie> selectAll() throws SQLException {
		String sql = "select * from movie join type on movie.no = type.no";

		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		List<Movie> movies = new ArrayList<>();

		try {
			conn = dbutil.getConnection();
			ps = conn.prepareStatement(sql);

			rs = ps.executeQuery();
			if (rs.next())
				movies.add(new Movie(rs.getString("code"), rs.getString("title"), rs.getInt("price"),
						rs.getString("no"), rs.getString("name")));

		} finally {
			dbutil.close(rs, ps, conn);
		}

		return movies;
	}

	@Override
	public Movie select(String code) throws SQLException {
		String sql = "select * from movie join type on movie.no = type.no where movie.code = ?";

		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		Movie movie = null;

		try {
			conn = dbutil.getConnection();
			ps = conn.prepareStatement(sql);
			ps.setString(1, code);

			rs = ps.executeQuery();
			if (rs.next())
				movie = new Movie(code, rs.getString("title"), rs.getInt("price"), rs.getString("no"),
						rs.getString("name"));

		} finally {
			dbutil.close(rs, ps, conn);
		}

		return movie;
	}

	@Override
	public List<Movie> selectTitle(String title) throws SQLException {
		String sql = "select * from movie join type on movie.no = type.no where movie.title like ?";

		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		List<Movie> movies = new ArrayList<>();

		try {
			conn = dbutil.getConnection();
			ps = conn.prepareStatement(sql);
			ps.setString(1, title);

			rs = ps.executeQuery();
			if (rs.next())
				movies.add(new Movie(rs.getString("code"), rs.getString("title"), rs.getInt("price"),
						rs.getString("no"), rs.getString("name")));

		} finally {
			dbutil.close(rs, ps, conn);
		}

		return movies;
	}

	@Override
	public List<Movie> selectPrice(int price) throws SQLException {
		String sql = "select * from movie join type on movie.no = type.no where movie.price <= ?";

		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		List<Movie> movies = new ArrayList<>();

		try {
			conn = dbutil.getConnection();
			ps = conn.prepareStatement(sql);
			ps.setInt(1, price);

			rs = ps.executeQuery();
			if (rs.next())
				movies.add(new Movie(rs.getString("code"), rs.getString("title"), rs.getInt("price"),
						rs.getString("no"), rs.getString("name")));

		} finally {
			dbutil.close(rs, ps, conn);
		}

		return movies;
	}

	@Override
	public int delete(String code) throws SQLException {
		String sql = "delete from movie where code = ?";

		Connection conn = null;
		PreparedStatement ps = null;

		int result = -1;
		try {
			conn = dbutil.getConnection();
			ps = conn.prepareStatement(sql);
			ps.setString(1, code);

			result = ps.executeUpdate();
		} finally {
			dbutil.close(ps, conn);
		}

		return result;
	}

	@Override
	public int update(Movie movie) throws SQLException {
		String sql = "update movie set title =?, price = ? no = ? where code= ?";

		Connection conn = null;
		PreparedStatement ps = null;

		int result = -1;
		try {
			conn = dbutil.getConnection();
			ps = conn.prepareStatement(sql);
			ps.setString(1, movie.getTitle());
			ps.setInt(2, movie.getPrice());
			ps.setString(3, movie.getNo());
			ps.setString(4, movie.getCode());

			result = ps.executeUpdate();
		} finally {
			dbutil.close(ps, conn);
		}

		return result;
	}

	public static void main(String[] args) throws SQLException {
		MovieDao movieDao = MovieDaoImpl.getInstance();
		System.out.println(movieDao.select("101"));
	}
}
