package com.ssafy.movie.controller;

import java.io.IOException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ssafy.movie.dto.Movie;
import com.ssafy.movie.dto.User;
import com.ssafy.movie.service.MovieService;
import com.ssafy.movie.service.MovieServiceImpl;
import com.ssafy.movie.service.UserService;
import com.ssafy.movie.service.UserServiceImpl;

/**
 * Servlet implementation class MainServlet
 */
@WebServlet("/main")
public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserService userSvc = UserServiceImpl.getInstance();
	private MovieService movieSvc = MovieServiceImpl.getInstance();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		process(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		process(request, response);
	}

	private void process(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("action");
		action = action == null ? "null" : action;

		System.out.println(userSvc);
		System.out.println(movieSvc);
		
		System.out.println("action=[" + action + "]");

		switch (action) {
		case "login":
			login(request, response);
			break;
		case "logout":
			logout(request, response);
			break;
		case "mvregist":
			mvregist(request, response);
			break;
		case "regist":
			regist(request, response);
			break;
		case "list":
			list(request, response);
			break;
		case "dele":
			dele(request, response);
			break;
		case "delm":
			delm(request, response);
			break;
		case "view":
			view(request, response);
			break;
		default:
			response.sendRedirect(request.getContextPath() + "/index.jsp");
		}

	}

	private void login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
		String pass = request.getParameter("pass");

		try {
			User user = userSvc.select(id);

			if (user != null && user.getPass().equals(pass)) {
				HttpSession session = request.getSession();
				session.setAttribute("user", user);

				request.getRequestDispatcher("/regist.jsp").forward(request, response);
			} else {
				request.setAttribute("msg", "로그인 실패");
				request.getRequestDispatcher("/index.jsp").forward(request, response);
			}

		} catch (Exception e) {
			e.printStackTrace();
			response.sendError(500);
		}
	}

	// 로그아웃
	private void logout(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false); // 세션이 있으며 넘어오고, 없으면 null이 날라옴
		if (session != null)
			session.invalidate();
		response.sendRedirect(request.getContextPath() + "/index.jsp");
	}

	private void mvregist(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.getRequestDispatcher("/regist.jsp").forward(request, response);
	}

	private void regist(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String code = request.getParameter("code");
		String title = request.getParameter("title");
		int price = Integer.parseInt(request.getParameter("price"));
		String no = request.getParameter("no");

		Movie movie = new Movie(code, title, price, no, "");
		try {
			
			movieSvc.insert(movie);
			request.setAttribute("msg", title + "등록 완료");
			request.getRequestDispatcher("/result.jsp").forward(request, response);

		} catch (SQLIntegrityConstraintViolationException e) {
			request.setAttribute("msg", "등록 중 문제가 발생");
			request.getRequestDispatcher("/error.jsp").forward(request, response);
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			response.sendError(500);
		}
	}

	private void list(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			List<Movie> movies = movieSvc.selectAll();
			request.setAttribute("movies", movies);
			request.getRequestDispatcher("/list.jsp").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
			response.sendError(500);
		}
	}

	private void view(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String code = request.getParameter("code");
		try {
			Movie movie = movieSvc.select(code);
			request.setAttribute("movie", movie);
			request.getRequestDispatcher("/list.jsp").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
			response.sendError(500);
		}
	}

	private void dele(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String code = request.getParameter("code");
		try {
			movieSvc.delete(code);
			request.getRequestDispatcher("/main?action=list.jsp").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
			response.sendError(500);
		}
	}

	private void delm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String[] codes = request.getParameterValues("codes");
		try {
			for (String code : codes)
				movieSvc.delete(code);
			request.getRequestDispatcher("/main?action=list.jsp").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
			response.sendError(500);
		}
	}
}
